
document.addEventListener('DOMContentLoaded', () => {
  const rqbModal = new bootstrap.Modal(document.getElementById('rqbModal'));
  rqbModal.show();
});
